//colors.dart
import 'package:flutter/material.dart';

Color color = Colors.blue;
Color homebuoyColor = Colors.deepOrange;
