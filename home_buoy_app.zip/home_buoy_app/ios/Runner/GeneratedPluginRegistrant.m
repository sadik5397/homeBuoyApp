//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_pdfview/PDFViewFlutterPlugin.h>)
#import <flutter_pdfview/PDFViewFlutterPlugin.h>
#else
@import flutter_pdfview;
#endif

#if __has_include(<pit_carousel/PitCarouselPlugin.h>)
#import <pit_carousel/PitCarouselPlugin.h>
#else
@import pit_carousel;
#endif

#if __has_include(<video_player/VideoPlayerPlugin.h>)
#import <video_player/VideoPlayerPlugin.h>
#else
@import video_player;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FLTPDFViewFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTPDFViewFlutterPlugin"]];
  [PitCarouselPlugin registerWithRegistrar:[registry registrarForPlugin:@"PitCarouselPlugin"]];
  [FLTVideoPlayerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTVideoPlayerPlugin"]];
}

@end
